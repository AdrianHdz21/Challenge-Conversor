import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GeneradorArchivos {
    public void guardarConversion(String monedaBase, double cantidadBase, String monedaConvertir, double cantidadConvertida, double tasaCambio) throws IOException {
        // Obtener la fecha y hora actual
        LocalDateTime fechaHoraActual = LocalDateTime.now();
        // Formatear la fecha y hora actual en un formato legible
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String fechaHoraFormateada = fechaHoraActual.format(formatter);

        // Crear un objeto que represente la conversión
        Conversion conversion = new Conversion(fechaHoraFormateada, monedaBase, cantidadBase, monedaConvertir, cantidadConvertida, tasaCambio);

        // Crear un objeto Gson para convertir el objeto a JSON
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        // Crear un FileWriter para escribir en el archivo
        FileWriter escritura = new FileWriter("conversion.json");
        // Convertir el objeto a JSON y escribirlo en el archivo
        gson.toJson(conversion, escritura);
        // Cerrar el FileWriter
        escritura.close();
    }

    // Clase para representar la conversión
    static class Conversion {
        String fechaHora;
        String monedaBase;
        double cantidadBase;
        String monedaConvertir;
        double cantidadConvertida;
        double tasaCambio;

        public Conversion(String fechaHora, String monedaBase, double cantidadBase, String monedaConvertir, double cantidadConvertida, double tasaCambio) {
            this.fechaHora = fechaHora;
            this.monedaBase = monedaBase;
            this.cantidadBase = cantidadBase;
            this.monedaConvertir = monedaConvertir;
            this.cantidadConvertida = cantidadConvertida;
            this.tasaCambio = tasaCambio;
        }
    }
}
