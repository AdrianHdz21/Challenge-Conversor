import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Map;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rpt = 1;
        while(rpt!=0){
            System.out.print("Ingrese la abreviatura de la moneda base (p.ej. USD): ");
            String monedaBase = scanner.next();
            System.out.print("Ingrese la cantidad a tasar: ");
            double cantidadBase = scanner.nextDouble();
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.print("Ingrese la abreviatura de la moneda a convertir (p.ej. ARS): ");
            String monedaConvertir = scanner.next();
            double cantidadConvertida;
            double tasaCambio = 0;

            try {
                String respuestaAPI = ObtenerRespuestaAPI.obtenerRespuestaAPI(monedaBase);
                JsonObject jsonObject = JsonParser.parseString(respuestaAPI).getAsJsonObject();
                String timeLastUpdateUtc = jsonObject.get("time_last_update_utc").getAsString();
                String baseCode = jsonObject.get("base_code").getAsString();
                JsonObject conversionRatesObject = jsonObject.getAsJsonObject("conversion_rates");

                System.out.println("\n-------------DATOS DE CONVERSIÓN-------------");
                System.out.println("Última actualización de las tasas de cambio: " + timeLastUpdateUtc);

                if (conversionRatesObject.has(monedaConvertir)) {
                    tasaCambio = conversionRatesObject.get(monedaConvertir).getAsDouble();
                    System.out.println("Tasa de cambio de " + monedaBase + " a " + monedaConvertir + ": " + tasaCambio);
                    cantidadConvertida = cantidadBase * tasaCambio;
                    System.out.println("Cantidad original: " + cantidadBase + " " + monedaBase);
                    System.out.println("Cantidad convertida: " + cantidadConvertida + " " + monedaConvertir);
                    System.out.println("-----------------------------------------");
                    // Después de imprimir los detalles de la conversión
                    GeneradorArchivos generadorArchivos = new GeneradorArchivos();
                    generadorArchivos.guardarConversion(monedaBase, cantidadBase, monedaConvertir, cantidadConvertida, tasaCambio);

                } else {
                    System.out.println("No se encontró la tasa de cambio para la moneda " + monedaConvertir);
                }
                System.out.printf("\n¿Desea tasar otra Moneda (Si=1/No=0)?: ");
                rpt = scanner.nextInt();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
      }
}