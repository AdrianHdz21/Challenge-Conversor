import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ObtenerRespuestaAPI {
    public static String obtenerRespuestaAPI(String monedaBase) throws IOException {
        String urlString = "https://v6.exchangerate-api.com/v6/c51bf11dcdaeab62bcafbd27/latest/" + monedaBase;
        URL url = new URL(urlString);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            StringBuilder respuesta = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    respuesta.append(linea);
                }
            }
            return respuesta.toString();
        } else {
            throw new RuntimeException("Error al obtener la respuesta de la API: " + responseCode);
        }
    }
}